
Hallo! Danke f�rs Herunterladen meiner Schrift!

Wichtig: Sie ist Donation Ware*, das bedeutet, dass die kommerzielle Nutzung eine Spende in angemessener H�he erfordert, am besten per Paypal an: 

paypal@anke-art.de

Oder ein Belegexemplar des mit meiner Schrift gestalteten Produktes an:
Anke Arnold, Goethestr. 47, 73249 Wernau, Germany

Vielen Dank! *Andere M�glichkeiten zu spenden (Amazon-/Dawanda-Wunschliste) habe ich bei www.anke-art.de aufgelistet, einfach dort auf den "Danke!"-Link klicken.

Viel Spa� mit meiner Schrift!
Anke