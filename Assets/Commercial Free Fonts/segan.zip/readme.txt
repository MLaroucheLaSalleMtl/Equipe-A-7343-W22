
Segan-Light.ttf
Free for commercial and personal use. Download and use this font freely commercially 
or personally. This weight will be free forever, however I will be making Lighter, heavier, and italicized versions in the future. I designed this font out of a desire to give another system-like feel to what Windows already provides. Some glyphs have yet to be added.

felinefury82@gmail.com
I do have an OpenType version with swashes and alternates too.
