
Hallo! Danke f�rs Herunterladen meiner Schrift!

"Krystal" und "Hole Hearted" sind tats�chlich komplett kostenlos und d�rfen kommerziell eingesetzt werden. Toll, nicht wahr? Nat�rlich freue ich mich �ber Belegexemplare von Produkten, die mit meinen Schriften erstellt werden, und ich verlinke gerne zu entsprechenden Seiten. Kontakt via anke-art.de

Viel Spa� mit meinen Schriften!
Anke
www.anke-art.de

_____________________________________________

Hi and thank you for downloading my font!

"Krystal" and "Hole Hearted" are completely free for personal and even commercial use. Cool, huh? I'm happy about product samples, and I'll gladly link back to your site if you use my font(s). Just drop me a line via my website.

Have fun!
Anke
www.anke-art.de/en/