BAD Motherf**ka' 
by chris