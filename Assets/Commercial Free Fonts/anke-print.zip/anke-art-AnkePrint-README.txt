
Hallo! Danke f�rs Herunterladen meiner Schrift!

"AnkePrint" ist tats�chlich komplett kostenlos und darf kommerziell eingesetzt werden. Toll, nicht wahr?

Viel Spa� mit meiner Schrift!
Anke
www.anke-art.de

_____________________________________________

Hi and thank you for downloading my font!

"AnkePrint" is completely free for personal and even commercial use. Cool, huh?

Have fun!
Anke
www.anke-art.de