this typeface is for free and meant "as is". you can copy and give it away to your friends as long as this readme-file is included with the postscript data.
don't try to distribute it!
© signalgrau | designbureau
ladenspelder str. 42
d-45147 essen
+49.201.730511
say hello - wave goodbye or let us know what you've made with the font
post@signalgrau.com
