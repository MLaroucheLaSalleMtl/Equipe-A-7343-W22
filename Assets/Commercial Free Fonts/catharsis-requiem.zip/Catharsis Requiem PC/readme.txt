Catharsis Requiem
*****************

A TrueType font created by Christian Thalmann (cinga at gmx dot
net).  Distribute and use freely, but not without this readme file.

The bold face isn't just thicker than the regular face, it uses
an isotropic solid line rather than a calligraphic pen.

-- Christian Thalmann