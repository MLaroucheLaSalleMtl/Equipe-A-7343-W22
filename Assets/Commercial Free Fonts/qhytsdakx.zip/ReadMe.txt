T E P I D   M O N K E Y   F O N T S
freeware fonts for a freeware world

- http://www.tepidmonkey.com/
- brandon@tepidmonkey.com

Thanks for downloading a Tepid Monkey 
Fonts typeface! For help with installing 
the font, visit the Help area of 
Tepid Monkey Fonts (www.tepidmonkey.com).

The terms of use are basically this:
don't sell the font, don't change the
font but do feel free to use the font
freely for commercial and non-commercial
purposes. For a complete list of the
terms (which always takes precedence
over this anyway), visit the Terms
section of Tepid Monkey Fonts.

--Brandon Schoepf