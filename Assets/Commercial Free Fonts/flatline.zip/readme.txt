Have a free font, Jerk!
Check out my other fonts..
http://www.cheapskatefonts/
feel free to distribute this font as long as you include this readme file. 
Thanx, enjoy the font!