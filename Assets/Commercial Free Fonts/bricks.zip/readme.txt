Bricks

This is a freeware True Type font by Carol Brooksbank.

It may be offered for download and distributed freely so long as its authorship is credited. A link to my site would be appreciated

http://members.tripod.com/~brooksbank/graphics


Email
Carol@Brooksbank.softnet.co.uk

Please not that because of the nature of the texture used in this font it will be more satisfactory at sizes 24 and above.