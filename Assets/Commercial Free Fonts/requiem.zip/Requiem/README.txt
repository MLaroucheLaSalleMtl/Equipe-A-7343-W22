Requiem Created by Chris Hansen/Livin Hell all rights reserved, 2004.
Contact: Crizcrack_666@hotmail.com
www.geocities.com/crizcrack666

Terms of usage 

You may use my fonts, for your personal needs, etc. a personal homepage, custom stickers, etc, for your boat, is alright-If ya feel like it i prefer being credited..
BUT, if you intend to use them in any commercial way, contact me first. Depending on what kind of commercial intentions you have, we'll work somethin out.

This font is free, but only for Personal use, if you intend using it any way commercially please contact me and we can work out an agreement, depending on wha/crizcrack666