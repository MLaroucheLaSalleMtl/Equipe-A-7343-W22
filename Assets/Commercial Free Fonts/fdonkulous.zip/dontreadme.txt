F'Donkulous
by Daniel Carter

minidan492@yahoo.co.uk

-------------------------

This font is freeware, so basically I don't mind you using it for either non-commercial or commercial use.
HOWEVER, I would rather like being informed if you use it commercially.
Just so I know where and what it's being used for.

Also, I don't want this font to be altered or copied.
It's mine so leave it...

And of course, strictly NO REDISTRIBUTION!!

