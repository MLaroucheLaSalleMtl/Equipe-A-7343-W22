--------------------------------------------------August 4, 2000------
                                          readme altered 11-3-01
Hi there! Thanks for checking out Lumos v.1, a freeware font inspired 
by the Harry Potter books! I made this font after long unsuccessful 
searches for the display font used in the US editions of Harry Potter. 
I am excited to use the font, and I am equally happy to share it with 
other fans of J.K. Rowling's fabulous books. 

TO USE THIS FONT: copy lumos.ttf to your Fonts folder in the Windows 
directory.

You can use it in CAPS ONLY for a more true-to-the-book look, or use 
the 'small-caps' (lowercase) letters which have a few quirky variations. 
Don't forget to be on the lookout for the hidden dingbats -- I think I 
put in six. If you look really hard, you might find the super-tiny 
golden snitch! :-)

You are welcome to share this font with your friends. Please distribute 
it with this readme (the zip file is an easy way to pass it along!)

Enjoy!
><> Sarah McFalls
CarpeSaponem Fonts
hedwig@owlmail.com  <---contact me here w/any questions!
http://www.geocities.com/carpesaponem/