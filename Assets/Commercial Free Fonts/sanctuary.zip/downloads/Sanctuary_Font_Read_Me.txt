Sanctuary Font by Chad Savage
http://www.sinistervisions.com

Created 2004 based on a hand-lettered logo design I did for a club called Sanctuary in Syracuse, New York, in 1996.

This is a free font, and I mean FREE. Use it however you want, for whatever you want. If you make something cool with it, I'd love to see it - email me at savage@sinistervisions.com and tell me about it. If you offer it for download on your own font site, PLEASE include this Read Me. That's not too much to ask, is it?

This font is intended for specialty and graphic uses. It has only letters - no numbers or punctuation. It will look just awful if used in a paragraph format.

For more free fonts and other downloadable goodies, visit http://www.sinisterfonts.com.